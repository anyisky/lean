This is the TypeScript declaration of Vuex.

## Testing

```sh
$ tsc -p test/tsconfig.json
```
